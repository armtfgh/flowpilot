# FlowPilot Ablation Benchmark Report

Generated: 2026-07-28T05:52:20.320254+00:00

## Scope

- Frozen literature-derived cases: 12
- Adversarial engineering cases available: 8
- THQ is excluded by an automated content audit.
- Hidden source records are excluded from retrieval on a per-case basis.
- Machine-extracted literature records require verification against original papers before manuscript use.

## Execution

- Run summaries found: 67
- Completed cells: 59
- Status counts: `{"completed": 59, "failed": 8}`

## Primary Results

Architecture composite scores (fixed model: `qwen`):

| variant          |     mean |       std |   count |
|:-----------------|---------:|----------:|--------:|
| no_engineering   | 0.928358 | 0.0701522 |      12 |
| no_council       | 0.920442 | 0.0827763 |      12 |
| general_one_shot | 0.89365  | 0.100962  |      12 |

Full-pipeline model portability:

| bundle_name   |   mean |   std |   count |
|:--------------|-------:|------:|--------:|
| claude        | 0.7143 |   nan |       1 |
| gemma         | 0.5714 |   nan |       1 |
| qwen          | 0.5714 |   nan |       1 |

## Automated Findings

- Geometry pass rate by variant: `general_one_shot` 100%, `no_council` 83%, `no_engineering` 92%.
- Required gas-bookkeeping pass rate: `general_one_shot` 50%, `no_council` 0%, `no_engineering` 50%.
- Unexpected gas streams in matched non-gas cases: 0.
- Full-pipeline cost and geometry: `claude`: 63 calls, 392490 tokens, geometry pass=False; `gemma`: 74 calls, 122994 tokens, geometry pass=False; `qwen`: 25 calls, 107546 tokens, geometry pass=False.
- These are automated screening findings. Expert scores remain pending.

## Interpretation Rules

- Architecture claims must use the fixed-model architecture arm only.
- Model claims must use the full-pipeline portability arm only.
- Surrogate or partial references are reported separately from primary reference-accuracy statistics.
- Keyword coverage is an automated screening metric, not expert validation.
- Failed and credential-blocked cells remain in the denominator and failure table.

## Artifacts

- `tables/all_runs.csv`: one row per discovered run.
- `tables/aggregate_architecture.csv`: architecture summary.
- `tables/aggregate_portability.csv`: model summary.
- `expert_scoring/expert_scoring_blinded.csv`: blinded review form.
- `figures/`: PNG and vector PDF versions of every figure.
- `tables/agent_call_events.csv`: call-level model/component proof with prompt and response hashes.
- `reports/agent_trace_summary.md`: concise full-pipeline call trace.
- `runs/`: raw prompts, completions, snapshots, metrics, logs, and checksums.
