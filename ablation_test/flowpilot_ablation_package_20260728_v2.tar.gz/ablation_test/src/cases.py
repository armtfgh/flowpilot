from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parents[1]
FORBIDDEN_CASE_TERMS = (
    "tetrahydroquinoline",
    "6-methylquinoline",
    "profpark",
)


@dataclass(frozen=True)
class AblationCase:
    case_id: str
    title: str
    protocol: str
    suite_id: str
    category: str
    difficulty: str = "high"
    tags: tuple[str, ...] = ()
    source_record_id: str = ""
    source_record_aliases: tuple[str, ...] = ()
    reference_quality: str = "not_applicable"
    expected_features: dict[str, Any] = field(default_factory=dict)
    reference_flow: dict[str, Any] = field(default_factory=dict)

    @property
    def protocol_sha256(self) -> str:
        return hashlib.sha256(self.protocol.encode("utf-8")).hexdigest()

    @property
    def excluded_record_ids(self) -> set[str]:
        return {
            value
            for value in (self.source_record_id, *self.source_record_aliases)
            if value
        }

    def public_payload(self) -> dict[str, Any]:
        """Payload allowed to enter an LLM prompt."""
        return {
            "case_id": self.case_id,
            "title": self.title,
            "protocol": self.protocol,
            "category": self.category,
            "objective": (
                "Translate the batch protocol into a feasible, safe, and testable "
                "continuous-flow design."
            ),
        }

    def manifest_payload(self) -> dict[str, Any]:
        return {
            **self.public_payload(),
            "suite_id": self.suite_id,
            "difficulty": self.difficulty,
            "tags": list(self.tags),
            "source_record_id": self.source_record_id,
            "source_record_aliases": list(self.source_record_aliases),
            "reference_quality": self.reference_quality,
            "expected_features": self.expected_features,
            "reference_flow": self.reference_flow,
            "protocol_sha256": self.protocol_sha256,
        }


def _load_file(path: Path) -> list[AblationCase]:
    payload = json.loads(path.read_text(encoding="utf-8"))
    suite_id = payload["suite_id"]
    cases: list[AblationCase] = []
    for raw in payload["cases"]:
        cases.append(
            AblationCase(
                case_id=raw["case_id"],
                title=raw["title"],
                protocol=raw["protocol"],
                suite_id=suite_id,
                category=raw["category"],
                difficulty=raw.get("difficulty", "high"),
                tags=tuple(raw.get("tags", [])),
                source_record_id=raw.get("source_record_id", ""),
                source_record_aliases=tuple(raw.get("source_record_aliases", [])),
                reference_quality=raw.get("reference_quality", "not_applicable"),
                expected_features=raw.get("expected_features", {}),
                reference_flow=raw.get("reference_flow", {}),
            )
        )
    return cases


def load_cases(include_adversarial: bool = False) -> list[AblationCase]:
    cases = _load_file(ROOT / "protocols" / "literature_cases.json")
    if include_adversarial:
        cases.extend(_load_file(ROOT / "protocols" / "adversarial_cases.json"))
    assert_no_forbidden_cases(cases)
    ids = [case.case_id for case in cases]
    if len(ids) != len(set(ids)):
        raise ValueError("Duplicate case IDs in ablation suite")
    return cases


def assert_no_forbidden_cases(cases: list[AblationCase]) -> None:
    violations: list[str] = []
    for case in cases:
        searchable = f"{case.case_id}\n{case.title}\n{case.protocol}".lower()
        for term in FORBIDDEN_CASE_TERMS:
            if term.lower() in searchable:
                violations.append(f"{case.case_id}: {term}")
    if violations:
        raise ValueError("Forbidden case contamination: " + ", ".join(violations))


def select_cases(
    cases: list[AblationCase],
    requested_ids: list[str],
) -> list[AblationCase]:
    if requested_ids == ["*"]:
        return cases
    by_id = {case.case_id: case for case in cases}
    missing = [case_id for case_id in requested_ids if case_id not in by_id]
    if missing:
        raise KeyError(f"Unknown case IDs: {missing}")
    return [by_id[case_id] for case_id in requested_ids]

