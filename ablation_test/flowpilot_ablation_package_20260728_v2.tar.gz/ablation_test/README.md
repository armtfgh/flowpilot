# FlowPilot Ablation Test

This directory is a self-contained, reproducible evaluation package for
FlowPilot. It deliberately excludes the THQ case study.

## Evaluation arms

Architecture ablation uses a fixed model bundle:

- `general_one_shot`: general LLM with the batch protocol only.
- `structured_single_agent`: one structured FlowProposal call.
- `no_retrieval`: FlowPilot with literature retrieval disabled.
- `no_engineering`: structured LLM output without deterministic calculations.
- `no_council`: FlowPilot upstream proposal before council deliberation.
- `no_inventory`: full council with an intentionally permissive inventory.
- `full`: complete FlowPilot pipeline.

Model portability is a separate experiment and does not get mixed with the
architecture ablation:

- Claude upstream and Claude council.
- Qwen upstream and Qwen council.
- Gemma upstream and Gemma council.
- Claude upstream and Qwen council.

GPT-4o configurations are included in the configuration, but runs are marked
`blocked_missing_credential` when `OPENAI_API_KEY` is unavailable.

## Data boundaries

The files under `protocols/` contain a batch-only prompt and a hidden reference
flow result. The reference is used only by the external metric calculator. The
corresponding source record is excluded from retrieval. `scripts/audit.py`
checks for THQ text and hidden-answer contamination.

The local literature records are machine-extracted and must be checked against
the original papers before publication. They are suitable for engineering the
evaluation harness, not a substitute for human source verification.

## Run

```bash
python -m ablation_test.scripts.audit
python -m ablation_test.scripts.run --profile smoke
python -m ablation_test.scripts.run --profile pilot
python -m ablation_test.scripts.analyze
python -m pytest ablation_test/tests -q
```

Every run gets a timestamped directory under `runs/` with:

- full LLM prompts and completions;
- stage and error logs;
- parsed intermediate JSON snapshots;
- final output and deterministic metrics;
- environment and model endpoint manifests;
- SHA-256 checksums.

Aggregated CSV/JSON tables, expert-review sheets, figures, and the generated
report are written to `tables/`, `figures/`, `expert_scoring/`, and `reports/`.

