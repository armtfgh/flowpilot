from __future__ import annotations

import csv
import hashlib
import json
import math
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns

from ablation_test.src.cases import ROOT, load_cases
from ablation_test.src.metrics import score_run
from ablation_test.src.runner import write_checksums


TABLES = ROOT / "tables"
FIGURES = ROOT / "figures"
REPORTS = ROOT / "reports"
EXPERT = ROOT / "expert_scoring"


def _flatten(prefix: str, value: Any, output: dict[str, Any]) -> None:
    if isinstance(value, dict):
        for key, item in value.items():
            _flatten(f"{prefix}_{key}" if prefix else key, item, output)
    elif not isinstance(value, (list, tuple)):
        output[prefix] = value


def _load_rows() -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for summary_path in sorted((ROOT / "runs").glob("**/run_summary.json")):
        run_dir = summary_path.parent
        summary = json.loads(summary_path.read_text(encoding="utf-8"))
        metrics_path = run_dir / "metrics.json"
        metadata_path = run_dir / "metadata.json"
        metadata = {}
        if metadata_path.exists():
            raw = json.loads(metadata_path.read_text(encoding="utf-8"))
            metadata = raw.get("metadata", raw)
        metrics = (
            json.loads(metrics_path.read_text(encoding="utf-8"))
            if metrics_path.exists()
            else {}
        )
        row: dict[str, Any] = {
            "run_dir": str(run_dir),
            "arm": (
                "architecture"
                if "architecture" in run_dir.parts
                else "portability"
                if "portability" in run_dir.parts
                else "unknown"
            ),
            "status": summary.get("status", "unknown"),
            "runtime_s": summary.get("runtime_total_s", summary.get("runtime_s")),
            "llm_call_count": summary.get("llm_call_count", 0),
            "total_tokens": (summary.get("token_totals") or {}).get("total_tokens", 0),
        }
        _flatten("", metadata, row)
        _flatten("", metrics, row)
        rows.append(row)
    return rows


def _rescore_existing_runs(cases) -> None:
    by_id = {case.case_id: case for case in cases}
    for result_path in sorted((ROOT / "runs").glob("**/result.json")):
        run_dir = result_path.parent
        metadata_path = run_dir / "metadata.json"
        if not metadata_path.exists():
            continue
        metadata_payload = json.loads(metadata_path.read_text(encoding="utf-8"))
        metadata = metadata_payload.get("metadata", metadata_payload)
        case = by_id.get(metadata.get("case_id"))
        if case is None:
            continue
        try:
            result = json.loads(result_path.read_text(encoding="utf-8"))
        except json.JSONDecodeError:
            continue
        metrics = score_run(case, result, run_dir)
        (run_dir / "metrics.json").write_text(
            json.dumps(metrics, indent=2, ensure_ascii=False),
            encoding="utf-8",
        )
        summary_path = run_dir / "run_summary.json"
        if summary_path.exists():
            summary = json.loads(summary_path.read_text(encoding="utf-8"))
            if summary.get("status") == "completed":
                summary["external_metrics"] = metrics
                summary_path.write_text(
                    json.dumps(summary, indent=2, ensure_ascii=False),
                    encoding="utf-8",
                )
        write_checksums(run_dir)


def _savefig(name: str) -> None:
    plt.tight_layout()
    plt.savefig(FIGURES / f"{name}.png", dpi=240, bbox_inches="tight", facecolor="white")
    plt.savefig(FIGURES / f"{name}.pdf", bbox_inches="tight", facecolor="white")
    plt.close()


def _empty_figure(name: str, title: str, note: str) -> None:
    plt.figure(figsize=(8, 4.5))
    plt.axis("off")
    plt.text(0.5, 0.60, title, ha="center", va="center", fontsize=16, weight="bold")
    plt.text(0.5, 0.42, note, ha="center", va="center", fontsize=11, wrap=True)
    _savefig(name)


def _primary_architecture(completed: pd.DataFrame) -> tuple[pd.DataFrame, str]:
    architecture = completed[completed["arm"] == "architecture"].copy()
    if architecture.empty:
        return architecture, ""
    primary_bundle = (
        architecture.groupby("bundle_name")["case_id"]
        .nunique()
        .sort_values(ascending=False)
        .index[0]
    )
    architecture = architecture[architecture["bundle_name"] == primary_bundle]
    architecture = architecture.sort_values("run_dir").drop_duplicates(
        ["variant", "case_id"],
        keep="last",
    )
    variant_counts = architecture.groupby("variant")["case_id"].nunique()
    if not variant_counts.empty:
        coverage_floor = max(2, math.ceil(0.5 * variant_counts.max()))
        eligible_variants = set(
            variant_counts[variant_counts >= coverage_floor].index
        )
        architecture = architecture[architecture["variant"].isin(eligible_variants)]
        case_sets = [
            set(group["case_id"])
            for _, group in architecture.groupby("variant")
        ]
        common_cases = set.intersection(*case_sets) if case_sets else set()
        if common_cases:
            architecture = architecture[architecture["case_id"].isin(common_cases)]
    return architecture, primary_bundle


def _suite_figures(cases) -> None:
    categories = Counter(case.category for case in cases)
    plt.figure(figsize=(10, 5.5))
    order = [name for name, _ in categories.most_common()]
    sns.barplot(x=[categories[name] for name in order], y=order, color="#2f6f6d")
    plt.title("Benchmark Case Coverage")
    plt.xlabel("Number of cases")
    plt.ylabel("")
    _savefig("01_case_category_coverage")

    literature = [case for case in cases if case.reference_flow]
    fields = ("residence_time_min", "flow_rate_mL_min", "temperature_C", "reactor_volume_mL")
    data = []
    for case in literature:
        for field in fields:
            value = case.reference_flow.get(field)
            if isinstance(value, (int, float)) and value > 0:
                data.append({"case_id": case.case_id, "field": field, "value": value})
    if data:
        frame = pd.DataFrame(data)
        fig, axes = plt.subplots(2, 2, figsize=(12, 8))
        for ax, field in zip(axes.flat, fields):
            subset = frame[frame["field"] == field]
            sns.stripplot(data=subset, x="value", ax=ax, color="#9b3a3a", size=7)
            if field != "temperature_C":
                ax.set_xscale("log")
            ax.set_title(field.replace("_", " "))
            ax.set_ylabel("")
        fig.suptitle("Hidden Reference Design Range", y=1.01, fontsize=15)
        _savefig("02_reference_design_range")

    hazard_counts = Counter()
    topology_counts = Counter()
    for case in cases:
        hazard_counts.update(case.expected_features.get("hazards", []))
        topology_counts.update(case.expected_features.get("topology", []))

    for name, counts, title, color in (
        ("03_hazard_coverage", hazard_counts, "Required Hazard Recognition Coverage", "#a64545"),
        ("04_topology_requirement_coverage", topology_counts, "Required Unit-Operation Coverage", "#3d668f"),
    ):
        common = counts.most_common(18)
        plt.figure(figsize=(10, 6))
        sns.barplot(
            x=[count for _, count in common],
            y=[label.replace("_", " ") for label, _ in common],
            color=color,
        )
        plt.title(title)
        plt.xlabel("Cases requiring feature")
        plt.ylabel("")
        _savefig(name)


def _result_figures(frame: pd.DataFrame) -> None:
    completed = frame[frame["status"] == "completed"].copy()
    if completed.empty:
        for name, title in (
            ("05_architecture_composite", "Architecture Composite Score"),
            ("06_architecture_metric_heatmap", "Architecture Metric Heatmap"),
            ("07_model_portability", "Model Portability"),
            ("08_case_variant_heatmap", "Per-Case Architecture Scores"),
            ("09_runtime_by_variant", "Runtime by Variant"),
            ("10_token_cost_by_variant", "Token Use by Variant"),
            ("11_geometry_consistency", "Geometry Consistency"),
            ("12_inventory_feasibility", "Inventory Feasibility"),
            ("13_safety_topology", "Safety and Topology Coverage"),
            ("14_reference_accuracy", "Hidden-Reference Accuracy"),
            ("15_gas_bookkeeping", "Gas Bookkeeping"),
            ("16_score_vs_calls", "Score vs LLM Calls"),
            ("17_metric_correlation", "Metric Correlation"),
        ):
            _empty_figure(name, title, "No completed result cells were available when analysis ran.")
        return

    score = "deterministic_composite_score"
    architecture, primary_bundle = _primary_architecture(completed)

    if score in architecture:
        plt.figure(figsize=(10, 5.5))
        order = architecture.groupby("variant")[score].mean().sort_values(ascending=False).index
        sns.barplot(data=architecture, x=score, y="variant", order=order, color="#286f6b", errorbar=None)
        plt.xlim(0, 1)
        plt.title(f"Architecture Composite Score ({primary_bundle}, matched model)")
        plt.xlabel("Deterministic composite (0-1)")
        plt.ylabel("")
        _savefig("05_architecture_composite")

    metric_cols = [
        "numeric_completeness",
        "geometry_consistent_10pct",
        "inventory_pump_feasible",
        "inventory_tubing_feasible",
        "topology_coverage",
        "safety_coverage",
        "gas_bookkeeping_complete",
    ]
    available = [column for column in metric_cols if column in architecture]
    if available:
        numeric_metrics = architecture[["variant", *available]].copy()
        for column in available:
            numeric_metrics[column] = pd.to_numeric(
                numeric_metrics[column], errors="coerce"
            )
        heat = numeric_metrics.groupby("variant")[available].mean()
        plt.figure(figsize=(11, max(4, 0.55 * len(heat))))
        sns.heatmap(heat, annot=True, fmt=".2f", vmin=0, vmax=1, cmap="RdYlGn", cbar_kws={"label": "Mean score"})
        plt.title("Architecture Metric Heatmap")
        plt.xlabel("")
        plt.ylabel("")
        _savefig("06_architecture_metric_heatmap")

    portability = completed[
        (completed["arm"] == "portability") & (completed["variant"] == "full")
    ]
    if not portability.empty and score in portability:
        plt.figure(figsize=(9, 5))
        order = portability.groupby("bundle_name")[score].mean().sort_values(ascending=False).index
        sns.barplot(data=portability, x=score, y="bundle_name", order=order, color="#536f9e", errorbar=None)
        plt.xlim(0, 1)
        plt.title("Full-Pipeline Model Portability")
        plt.xlabel("Deterministic composite (0-1)")
        plt.ylabel("")
        _savefig("07_model_portability")
    else:
        _empty_figure("07_model_portability", "Model Portability", "No completed full-pipeline portability cells.")

    if score in architecture and {"case_id", "variant"}.issubset(architecture):
        pivot = architecture.pivot_table(index="case_id", columns="variant", values=score, aggfunc="mean")
        plt.figure(figsize=(12, max(5, 0.45 * len(pivot))))
        sns.heatmap(pivot, annot=True, fmt=".2f", vmin=0, vmax=1, cmap="RdYlGn")
        plt.title("Per-Case Architecture Scores")
        plt.xlabel("")
        plt.ylabel("")
        _savefig("08_case_variant_heatmap")

    for name, column, title, xlabel, color in (
        ("09_runtime_by_variant", "runtime_s", "Runtime by Variant", "Seconds", "#7a5c91"),
        ("10_token_cost_by_variant", "total_tokens", "Token Use by Variant", "Tokens", "#8c6b32"),
    ):
        if column in architecture and architecture[column].notna().any():
            plt.figure(figsize=(10, 5.5))
            sns.barplot(data=architecture, x=column, y="variant", color=color, errorbar=None)
            plt.title(title)
            plt.xlabel(xlabel)
            plt.ylabel("")
            _savefig(name)
        else:
            _empty_figure(name, title, f"No {xlabel.lower()} telemetry available.")

    binary_panels = (
        ("11_geometry_consistency", "geometry_consistent_10pct", "Geometry Consistency"),
        ("12_inventory_feasibility", "inventory_pump_feasible", "Pump Feasibility"),
        ("15_gas_bookkeeping", "gas_bookkeeping_complete", "Gas Bookkeeping Completeness"),
    )
    for name, column, title in binary_panels:
        if column in architecture:
            binary = architecture[["variant", column]].copy()
            binary[column] = pd.to_numeric(binary[column], errors="coerce")
            values = binary.groupby("variant")[column].mean().sort_values(ascending=False)
            plt.figure(figsize=(9, 5))
            sns.barplot(x=values.values, y=values.index, color="#467c68")
            plt.xlim(0, 1)
            plt.title(title)
            plt.xlabel("Passing fraction")
            plt.ylabel("")
            _savefig(name)

    coverage_cols = [column for column in ("safety_coverage", "topology_coverage") if column in architecture]
    if coverage_cols:
        melted = architecture.melt(
            id_vars=["variant"],
            value_vars=coverage_cols,
            var_name="metric",
            value_name="score",
        )
        plt.figure(figsize=(10, 5.5))
        sns.barplot(data=melted, x="score", y="variant", hue="metric", errorbar=None)
        plt.xlim(0, 1)
        plt.title("Safety and Topology Coverage")
        plt.xlabel("Coverage")
        plt.ylabel("")
        _savefig("13_safety_topology")

    if "reference_accuracy_score" in architecture and architecture["reference_accuracy_score"].notna().any():
        ref = architecture[architecture["reference_accuracy_score"].notna()]
        plt.figure(figsize=(10, 5.5))
        sns.boxplot(data=ref, x="reference_accuracy_score", y="variant", color="#c2d6cf")
        sns.stripplot(data=ref, x="reference_accuracy_score", y="variant", color="#244d47", size=4)
        plt.xlim(0, 1)
        plt.title("Hidden-Reference Accuracy")
        plt.xlabel("Reference similarity score")
        plt.ylabel("")
        _savefig("14_reference_accuracy")
    else:
        _empty_figure("14_reference_accuracy", "Hidden-Reference Accuracy", "No checkable hidden-reference values.")

    if score in architecture and "llm_call_count" in architecture:
        plt.figure(figsize=(8, 5.5))
        sns.scatterplot(
            data=architecture,
            x="llm_call_count",
            y=score,
            hue="variant",
            style="bundle_name" if "bundle_name" in completed else None,
            s=80,
        )
        plt.ylim(0, 1)
        plt.title("Quality-Cost Tradeoff")
        plt.xlabel("LLM calls")
        plt.ylabel("Deterministic composite")
        _savefig("16_score_vs_calls")

    correlation_cols = [
        column
        for column in (
            score,
            "numeric_completeness",
            "topology_coverage",
            "safety_coverage",
            "reference_accuracy_score",
            "runtime_s",
            "llm_call_count",
            "total_tokens",
        )
        if column in architecture and pd.api.types.is_numeric_dtype(architecture[column])
    ]
    if len(correlation_cols) >= 2:
        corr = architecture[correlation_cols].corr(numeric_only=True)
        plt.figure(figsize=(9, 7))
        sns.heatmap(corr, annot=True, fmt=".2f", cmap="vlag", center=0)
        plt.title("Metric Correlation")
        _savefig("17_metric_correlation")


def _status_figure(frame: pd.DataFrame) -> None:
    if frame.empty:
        _empty_figure("18_run_status", "Run Status", "No run summaries found.")
        return
    counts = frame["status"].value_counts()
    plt.figure(figsize=(8, 4.5))
    sns.barplot(x=counts.values, y=counts.index, color="#6d7480")
    plt.title("Run Status")
    plt.xlabel("Cells")
    plt.ylabel("")
    _savefig("18_run_status")


def _write_tables(frame: pd.DataFrame, cases) -> None:
    frame.to_csv(TABLES / "all_runs.csv", index=False)
    completed = frame[frame["status"] == "completed"] if not frame.empty else frame
    metrics = [
        column
        for column in (
            "deterministic_composite_score",
            "numeric_completeness",
            "geometry_consistent_10pct",
            "inventory_pump_feasible",
            "inventory_tubing_feasible",
            "topology_coverage",
            "safety_coverage",
            "gas_bookkeeping_complete",
            "reference_accuracy_score",
            "runtime_s",
            "llm_call_count",
            "total_tokens",
        )
        if column in completed
    ]
    architecture, _ = _primary_architecture(completed)
    if not architecture.empty and metrics:
        architecture.groupby("variant")[metrics].agg(["mean", "std", "count"]).to_csv(
            TABLES / "aggregate_architecture.csv"
        )
        full = completed[
            (completed["arm"] == "portability") & (completed["variant"] == "full")
        ]
        if not full.empty:
            full.groupby("bundle_name")[metrics].agg(["mean", "std", "count"]).to_csv(
                TABLES / "aggregate_portability.csv"
            )
    else:
        pd.DataFrame().to_csv(TABLES / "aggregate_architecture.csv", index=False)
        pd.DataFrame().to_csv(TABLES / "aggregate_portability.csv", index=False)

    case_rows = [case.manifest_payload() for case in cases]
    pd.json_normalize(case_rows).to_csv(TABLES / "case_manifest.csv", index=False)

    definitions = [
        ("numeric_completeness", "Fraction of seven required numeric design fields present."),
        ("geometry_consistent_10pct", "Whether stated volume agrees with stated flow and residence-time basis within 10%."),
        ("inventory_pump_feasible", "Whether at least one real laboratory pump supports the stated flow and pressure."),
        ("inventory_tubing_feasible", "Whether stated ID, temperature, and pressure match available tubing."),
        ("topology_coverage", "Keyword-audited coverage of required unit operations for the case."),
        ("safety_coverage", "Keyword-audited coverage of case-specific hazards and controls."),
        ("gas_bookkeeping_complete", "Gas designs separately report STP flow, in-channel flow, and equivalents."),
        ("unexpected_gas_stream", "A gas feed appears even though the case does not require a gas reagent."),
        ("reference_accuracy_score", "Exponential score from log-ratio errors against the hidden literature flow reference."),
        ("deterministic_composite_score", "Unweighted mean of completeness, geometry, pump, tubing, topology, safety, and gas bookkeeping."),
    ]
    pd.DataFrame(definitions, columns=["metric", "definition"]).to_csv(
        TABLES / "metric_definitions.csv", index=False
    )

    failures = frame[frame["status"] != "completed"] if not frame.empty else frame
    failures.to_csv(TABLES / "failure_analysis.csv", index=False)


def _write_expert_sheets(frame: pd.DataFrame) -> None:
    completed = frame[frame["status"] == "completed"] if not frame.empty else frame
    review_rows = []
    key_rows = []
    for _, row in completed.iterrows():
        identity = f"{row.get('run_dir', '')}"
        blind_id = "FP-" + hashlib.sha256(identity.encode()).hexdigest()[:10].upper()
        review_rows.append(
            {
                "blind_id": blind_id,
                "case_id": row.get("case_id", ""),
                "chemistry_correctness_1_5": "",
                "engineering_correctness_1_5": "",
                "safety_adequacy_1_5": "",
                "experimental_feasibility_1_5": "",
                "usefulness_as_first_experiment_1_5": "",
                "fatal_flaw_yes_no": "",
                "fatal_flaw_description": "",
                "reviewer_confidence_1_5": "",
                "comments": "",
            }
        )
        key_rows.append(
            {
                "blind_id": blind_id,
                "variant": row.get("variant", ""),
                "bundle": row.get("bundle_name", ""),
                "model": row.get("model", ""),
                "run_dir": identity,
            }
        )
    pd.DataFrame(review_rows).to_csv(EXPERT / "expert_scoring_blinded.csv", index=False)
    pd.DataFrame(key_rows).to_csv(EXPERT / "blinding_key_confidential.csv", index=False)


def _write_agent_call_evidence() -> None:
    rows: list[dict[str, Any]] = []
    trace_lines = [
        "# Agent Call Trace",
        "",
        "This index proves which model-backed components were called. Full prompt and "
        "completion bodies remain in each run's `llm_events.jsonl`.",
        "",
    ]
    for event_path in sorted((ROOT / "runs").glob("**/llm_events.jsonl")):
        run_dir = event_path.parent
        metadata_path = run_dir / "metadata.json"
        metadata = {}
        if metadata_path.exists():
            payload = json.loads(metadata_path.read_text(encoding="utf-8"))
            metadata = payload.get("metadata", payload)
        events = []
        for index, line in enumerate(event_path.read_text(encoding="utf-8").splitlines(), start=1):
            try:
                event = json.loads(line)
            except json.JSONDecodeError:
                continue
            component = event.get("api_name") or event.get("component") or "unknown"
            usage = event.get("usage") or {}
            prompt = f"{event.get('system_prompt', '')}\n{event.get('user_prompt', '')}"
            response = str(
                event.get("response_text")
                or event.get("raw_response_text")
                or ""
            )
            total_tokens = (
                usage.get("total_tokens")
                or (usage.get("input_tokens", 0) or 0) + (usage.get("output_tokens", 0) or 0)
                or (usage.get("prompt_tokens", 0) or 0) + (usage.get("completion_tokens", 0) or 0)
            )
            row = {
                "run_dir": str(run_dir),
                "case_id": metadata.get("case_id", ""),
                "variant": metadata.get("variant", ""),
                "bundle": metadata.get("bundle_name", ""),
                "event_index": index,
                "component": component,
                "provider": event.get("provider", ""),
                "model": event.get("model", ""),
                "duration_ms": event.get("duration_ms"),
                "total_tokens": total_tokens,
                "prompt_sha256": hashlib.sha256(prompt.encode()).hexdigest() if prompt.strip() else "",
                "response_sha256": hashlib.sha256(response.encode()).hexdigest() if response else "",
                "prompt_captured": bool(prompt.strip()),
                "response_captured": bool(response),
            }
            rows.append(row)
            events.append(row)
        if events and metadata.get("variant") == "full":
            trace_lines.extend(
                [
                    f"## {metadata.get('bundle_name', 'unknown')} / {metadata.get('case_id', 'unknown')}",
                    "",
                    f"- Run: `{run_dir}`",
                    f"- Calls: {len(events)}",
                    f"- Components: {', '.join(dict.fromkeys(row['component'] for row in events))}",
                    f"- Prompt bodies captured: {sum(row['prompt_captured'] for row in events)}/{len(events)}",
                    f"- Response bodies captured: {sum(row['response_captured'] for row in events)}/{len(events)}",
                    "",
                ]
            )

    call_frame = pd.DataFrame(rows)
    call_frame.to_csv(TABLES / "agent_call_events.csv", index=False)
    if not call_frame.empty:
        matrix = (
            call_frame.groupby(["bundle", "component"])
            .size()
            .rename("call_count")
            .reset_index()
        )
        matrix.to_csv(TABLES / "agent_call_matrix.csv", index=False)
        top = (
            call_frame["component"].value_counts().head(20).sort_values()
        )
        plt.figure(figsize=(10, 6))
        sns.barplot(x=top.values, y=top.index, color="#566b78")
        plt.title("Recorded Model Calls by Pipeline Component")
        plt.xlabel("Calls")
        plt.ylabel("")
        _savefig("19_agent_component_calls")
    else:
        pd.DataFrame(columns=["bundle", "component", "call_count"]).to_csv(
            TABLES / "agent_call_matrix.csv", index=False
        )
        _empty_figure(
            "19_agent_component_calls",
            "Recorded Agent Calls",
            "No LLM event logs were found.",
        )
    (REPORTS / "agent_trace_summary.md").write_text(
        "\n".join(trace_lines) + "\n",
        encoding="utf-8",
    )


def _write_report(frame: pd.DataFrame, cases) -> None:
    completed = frame[frame["status"] == "completed"] if not frame.empty else frame
    status_counts = frame["status"].value_counts().to_dict() if not frame.empty else {}
    lines = [
        "# FlowPilot Ablation Benchmark Report",
        "",
        f"Generated: {datetime.now(timezone.utc).isoformat()}",
        "",
        "## Scope",
        "",
        f"- Frozen literature-derived cases: {sum(bool(case.reference_flow) for case in cases)}",
        f"- Adversarial engineering cases available: {sum(not bool(case.reference_flow) for case in cases)}",
        "- THQ is excluded by an automated content audit.",
        "- Hidden source records are excluded from retrieval on a per-case basis.",
        "- Machine-extracted literature records require verification against original papers before manuscript use.",
        "",
        "## Execution",
        "",
        f"- Run summaries found: {len(frame)}",
        f"- Completed cells: {len(completed)}",
        f"- Status counts: `{json.dumps(status_counts, sort_keys=True)}`",
        "",
        "## Primary Results",
        "",
    ]
    if completed.empty:
        lines.append("No cells completed. Figures show suite composition and explicit no-data placeholders.")
    else:
        score = "deterministic_composite_score"
        architecture_rows, primary_bundle = _primary_architecture(completed)
        if score in architecture_rows:
            architecture = architecture_rows.groupby("variant")[score].agg(["mean", "std", "count"]).sort_values("mean", ascending=False)
            lines.extend([f"Architecture composite scores (fixed model: `{primary_bundle}`):", "", architecture.to_markdown(), ""])
        full = completed[
            (completed["arm"] == "portability") & (completed["variant"] == "full")
        ]
        if not full.empty and score in full:
            portability = full.groupby("bundle_name")[score].agg(["mean", "std", "count"]).sort_values("mean", ascending=False)
            lines.extend(["Full-pipeline model portability:", "", portability.to_markdown(), ""])

        lines.extend(["## Automated Findings", ""])
        if not architecture_rows.empty:
            geometry = architecture_rows.groupby("variant")[
                "geometry_consistent_10pct"
            ].mean()
            gas_cases = architecture_rows[
                architecture_rows.get("gas_required_by_case") == True
            ]
            unexpected = int(
                pd.to_numeric(
                    architecture_rows.get("unexpected_gas_stream"),
                    errors="coerce",
                ).fillna(0).sum()
            )
            lines.append(
                "- Geometry pass rate by variant: "
                + ", ".join(
                    f"`{variant}` {value:.0%}"
                    for variant, value in geometry.items()
                )
                + "."
            )
            if not gas_cases.empty:
                gas_rates = gas_cases.groupby("variant")[
                    "gas_bookkeeping_complete"
                ].mean()
                lines.append(
                    "- Required gas-bookkeeping pass rate: "
                    + ", ".join(
                        f"`{variant}` {value:.0%}"
                        for variant, value in gas_rates.items()
                    )
                    + "."
                )
            lines.append(
                f"- Unexpected gas streams in matched non-gas cases: {unexpected}."
            )
        if not full.empty:
            full_rows = []
            for _, row in full.sort_values("bundle_name").iterrows():
                full_rows.append(
                    f"`{row.get('bundle_name')}`: "
                    f"{int(row.get('llm_call_count') or 0)} calls, "
                    f"{int(row.get('total_tokens') or 0)} tokens, "
                    f"geometry pass={bool(row.get('geometry_consistent_10pct'))}"
                )
            lines.append("- Full-pipeline cost and geometry: " + "; ".join(full_rows) + ".")
        lines.append(
            "- These are automated screening findings. Expert scores remain pending."
        )
        lines.append("")

    lines.extend(
        [
            "## Interpretation Rules",
            "",
            "- Architecture claims must use the fixed-model architecture arm only.",
            "- Model claims must use the full-pipeline portability arm only.",
            "- Surrogate or partial references are reported separately from primary reference-accuracy statistics.",
            "- Keyword coverage is an automated screening metric, not expert validation.",
            "- Failed and credential-blocked cells remain in the denominator and failure table.",
            "",
            "## Artifacts",
            "",
            "- `tables/all_runs.csv`: one row per discovered run.",
            "- `tables/aggregate_architecture.csv`: architecture summary.",
            "- `tables/aggregate_portability.csv`: model summary.",
            "- `expert_scoring/expert_scoring_blinded.csv`: blinded review form.",
            "- `figures/`: PNG and vector PDF versions of every figure.",
            "- `tables/agent_call_events.csv`: call-level model/component proof with prompt and response hashes.",
            "- `reports/agent_trace_summary.md`: concise full-pipeline call trace.",
            "- `runs/`: raw prompts, completions, snapshots, metrics, logs, and checksums.",
        ]
    )
    (REPORTS / "benchmark_report.md").write_text("\n".join(lines) + "\n", encoding="utf-8")


def main() -> None:
    for directory in (TABLES, FIGURES, REPORTS, EXPERT):
        directory.mkdir(parents=True, exist_ok=True)
    sns.set_theme(style="whitegrid", context="notebook")
    cases = load_cases(include_adversarial=True)
    _rescore_existing_runs(cases)
    rows = _load_rows()
    frame = pd.DataFrame(rows)
    if frame.empty:
        frame = pd.DataFrame(
            columns=[
                "status",
                "variant",
                "bundle_name",
                "case_id",
                "run_dir",
                "runtime_s",
                "llm_call_count",
                "total_tokens",
            ]
        )
    for column in (
        "schema_valid",
        "geometry_checkable",
        "geometry_consistent_10pct",
        "inventory_pump_feasible",
        "inventory_tubing_feasible",
        "inventory_exact_reactor_match",
        "gas_bookkeeping_complete",
        "leave_one_source_out_pass",
    ):
        if column in frame:
            frame[column] = frame[column].map(
                {True: 1.0, False: 0.0, "True": 1.0, "False": 0.0}
            )
    _write_tables(frame, cases)
    _write_expert_sheets(frame)
    _suite_figures(cases)
    _result_figures(frame)
    _status_figure(frame)
    _write_agent_call_evidence()
    _write_report(frame, cases)
    summary = {
        "run_count": len(frame),
        "figure_png_count": len(list(FIGURES.glob("*.png"))),
        "figure_pdf_count": len(list(FIGURES.glob("*.pdf"))),
        "table_count": len(list(TABLES.glob("*.csv"))),
        "report": str(REPORTS / "benchmark_report.md"),
    }
    (REPORTS / "analysis_summary.json").write_text(
        json.dumps(summary, indent=2),
        encoding="utf-8",
    )
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
