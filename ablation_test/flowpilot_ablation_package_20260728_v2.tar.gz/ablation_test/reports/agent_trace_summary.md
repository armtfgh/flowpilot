# Agent Call Trace

This index proves which model-backed components were called. Full prompt and completion bodies remain in each run's `llm_events.jsonl`.

## claude / snar_4_fluoronitrobenzene_piperazine

- Run: `/home/amirreza/Documents/codes/Flow Agent/ablation_test/runs/smoke_claude_smoke_fixed_20260728/portability/full/claude/snar_4_fluoronitrobenzene_piperazine/repeat_01`
- Calls: 63
- Components: input_parser, chemistry_agent, translation_llm, call_llm, call_llm_with_tools_turn, output_formatter
- Prompt bodies captured: 63/63
- Response bodies captured: 9/63

## gemma / snar_4_fluoronitrobenzene_piperazine

- Run: `/home/amirreza/Documents/codes/Flow Agent/ablation_test/runs/smoke_gemma_smoke_20260728/portability/full/gemma/snar_4_fluoronitrobenzene_piperazine/repeat_01`
- Calls: 1
- Components: lightweight_input_parser
- Prompt bodies captured: 1/1
- Response bodies captured: 1/1

## gemma / snar_4_fluoronitrobenzene_piperazine

- Run: `/home/amirreza/Documents/codes/Flow Agent/ablation_test/runs/smoke_gemma_smoke_fixed_20260728/portability/full/gemma/snar_4_fluoronitrobenzene_piperazine/repeat_01`
- Calls: 74
- Components: lightweight_input_parser, lightweight_chemistry_agent, translation_llm, translation_llm_retry, translation_llm_repair, call_llm, output_formatter
- Prompt bodies captured: 74/74
- Response bodies captured: 74/74

## qwen / snar_4_fluoronitrobenzene_piperazine

- Run: `/home/amirreza/Documents/codes/Flow Agent/ablation_test/runs/smoke_qwen_smoke_fixed_20260728/portability/full/qwen/snar_4_fluoronitrobenzene_piperazine/repeat_01`
- Calls: 25
- Components: lightweight_input_parser, lightweight_chemistry_agent, translation_llm, call_llm, output_formatter
- Prompt bodies captured: 25/25
- Response bodies captured: 25/25

