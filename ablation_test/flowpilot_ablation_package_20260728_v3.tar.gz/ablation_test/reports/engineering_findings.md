# Engineering Findings From the Executed Ablation

## Evidence Base

- 20 frozen cases: 12 literature-derived and 8 adversarial.
- 67 recorded run summaries.
- 59 completed cells and 8 preserved failures.
- Broad matched architecture comparison: 12 cases with Qwen across
  `general_one_shot`, `no_engineering`, and `no_council`.
- Full-pipeline smoke comparison: one SNAr case each for Claude, Qwen, and
  Gemma.
- THQ exclusion and source-record availability audits passed.

## Findings

1. **Final geometry can drift after council.**

   All three completed full-pipeline smoke cells failed the external
   `V = Q x tau` consistency check. Claude reported 41.4 min, 0.0819 mL/min,
   and 22.6044 mL; the liquid-only product of flow and residence time is only
   3.39 mL. This means final council/revision fields are not recomputed as one
   atomic design.

2. **Atmosphere text can become a false reagent stream.**

   The SNAr protocol said "under air," although the chemistry layer correctly
   identified the reaction as oxygen-insensitive. Council problem framing
   nevertheless marked the process gas-liquid, and all full-pipeline model
   runs introduced an air feed. Phase classification must distinguish
   atmosphere metadata from a consumed gas reagent.

3. **Pressure-only gas protocols lack a stoichiometric supply policy.**

   When H2 or CO pressure was supplied without explicit equivalents, the
   deterministic calculator logged a target of 0.00 delivered equivalents.
   In contrast, the oxygen adversarial case with an explicit 2.0 equivalents
   correctly produced a 2.0-equivalent target. A pressure/solubility/conversion
   policy is required for gases whose batch description does not use
   equivalents.

4. **More pipeline stages did not monotonically improve automated quality.**

   On the matched 12-case Qwen set, the no-engineering arm had the highest
   automated composite and hidden-reference similarity. The pre-council
   deterministic arm improved tubing inventory compatibility but reduced
   geometry consistency and gas-bookkeeping performance. These metrics are
   screening measures, but they reject the assumption that deterministic
   calculation is automatically beneficial in its current form.

5. **Council cost is highly variable and can amplify sharply.**

   The full Claude smoke cell used 63 calls and 392,490 tokens over about
   26 minutes because weak-pool redesign and specialist rescoring repeated.
   Qwen used 25 calls and 107,546 tokens. Gemma used 74 calls and 122,994
   tokens, with many unusable specialist score responses. Publication
   comparisons require a hard matched call/token budget or explicit reporting
   of adaptive budget use.

6. **Local-model integration needs schema-specific handling.**

   Qwen required the vLLM `chat_template_kwargs.enable_thinking=false` control;
   `think=false` alone was ineffective. Gemma initially truncated the compact
   parser at 768 tokens and needed a 1,536-token limit. Gemma still returned
   most council content through its reasoning field and failed to provide
   usable specialist scores, leading to deterministic fallback.

7. **The structured single-agent baseline exposed schema noncompliance.**

   Both Qwen and Claude returned semantically useful JSON with incorrect
   container types for fields such as `stage_parameters` and `confidence`.
   Those cells are retained as failures. A future baseline should report both
   strict-schema success and coercible-schema success rather than silently
   repairing one and not the other.

8. **Retrieval was not evaluated in this execution.**

   The shell did not contain `OPENAI_API_KEY`, so embedding-based retrieval was
   skipped. Leave-one-source-out controls and contamination checks are
   implemented and passed, but `full` versus `no_retrieval` performance cannot
   be claimed from the current run data.

9. **Expert evaluation is still required.**

   Automated topology and safety coverage use explicit keyword-controlled
   screens. The package includes blinded expert sheets and a confidential
   key. Manuscript claims should be based on completed expert scoring and
   source-paper verification, not the automated composite alone.

## Recommended Next Code Work

1. Make phase classification authoritative from chemistry consumption and
   stoichiometry, not atmosphere words.
2. Create one final-design transaction that recomputes volume, all flow bases,
   stage volumes, and inventory selection after every council revision.
3. Add pressure-specified gas dosing with explicit assumptions and a required
   nonzero supply guard.
4. Add strict council call/token budgets and cache upstream context by case.
5. Add schema-constrained generation or provider-specific JSON repair while
   retaining a strict first-pass compliance metric.
6. Run the existing `no_retrieval`, `no_inventory`, and `full` arms across the
   matched case set after retrieval credentials and expert review are ready.
