from __future__ import annotations

import json
import math
import re
from pathlib import Path
from typing import Any

from .cases import AblationCase, ROOT


NUMERIC_FIELDS = (
    "residence_time_min",
    "flow_rate_mL_min",
    "temperature_C",
    "concentration_M",
    "BPR_bar",
    "reactor_volume_mL",
    "tubing_ID_mm",
)

FEATURE_KEYWORDS = {
    "liquid_pump": ("pump", "liquid feed"),
    "feed_pumps": ("pump", "feed"),
    "separate_feed_pumps": ("separate", "pump", "stream a", "stream b"),
    "stage_specific_feeds": ("stage", "feed", "stream"),
    "stage_1_feed_pumps": ("stage 1", "pump"),
    "oxygen_mass_flow_controller": ("oxygen", "mfc", "mass flow"),
    "hydrogen_mass_flow_controller": ("hydrogen", "mfc", "mass flow"),
    "chlorine_mass_flow_controller": ("chlorine", "mfc", "mass flow"),
    "CO_mass_flow_controller": ("carbon monoxide", "co ", "mfc", "mass flow"),
    "gas_liquid_mixer": ("gas-liquid", "gas liquid", "mixer", "t-mixer"),
    "mixer": ("mixer", "mixing"),
    "micromixer": ("micromixer", "micro mixer"),
    "high_intensity_mixer": ("mixer", "mixing"),
    "heated_reactor": ("heated", "temperature", "reactor"),
    "temperature_control": ("temperature", "cooling", "jacket"),
    "temperature_controlled_microreactor": ("microreactor", "temperature"),
    "cooled_reactor": ("cooled", "cooling", "-20"),
    "cooled_microreactor": ("cooled", "cooling", "microreactor"),
    "photoreactor": ("photoreactor", "irradiat", "led"),
    "back_pressure_regulator": ("back pressure", "bpr"),
    "catalyst_cartridge": ("cartridge", "packed bed", "catalyst bed"),
    "packed_bed": ("packed bed", "catalyst bed"),
    "packed_bed_or_slurry_strategy": ("packed bed", "slurry", "cstr"),
    "catalyst_retention": ("retain", "filter", "packed bed", "magnetic"),
    "collection": ("collect", "collection"),
    "collection_or_quench": ("collect", "quench"),
    "quench": ("quench",),
    "immediate_quench": ("immediate", "quench"),
    "inline_thiosulfate_quench": ("thiosulfate", "quench"),
    "quench_or_safe_collection": ("quench", "safe collection"),
    "off_gas_destruct": ("off-gas", "off gas", "destruct", "scrubber"),
    "scrubber": ("scrubber", "off-gas", "off gas"),
    "CO_detector": ("co detector", "carbon monoxide detector", "monitor"),
    "scrubber_or_vent": ("scrubber", "vent"),
    "pressure_monitoring": ("pressure monitor", "pressure sensor", "pressure"),
    "flush_strategy": ("flush", "cleaning"),
    "solids_compatible_feeding": ("slurry", "solids", "cstr", "agitated"),
    "large_bore_or_CSTR": ("large bore", "cstr", "stirred tank"),
    "stage_1_oxidation": ("stage 1", "oxidation"),
    "stage_1_reactor": ("stage 1", "reactor"),
    "interstage_addition": ("interstage", "downstream addition", "stage 2"),
    "delayed_amine_addition": ("amine", "downstream", "delayed", "stage 2"),
    "peroxide_conditioning_or_quench": ("peroxide", "quench", "condition"),
    "stage_2_amidation": ("stage 2", "amidation"),
    "stage_2_reactor": ("stage 2", "reactor"),
    "multiple_reactors": ("stage 1", "stage 2", "reactors"),
    "interstage_additions": ("interstage", "stage 2", "addition"),
    "separations_or_conditioning": ("separation", "condition", "quench"),
    "back_pressure_control": ("back pressure", "bpr"),
}

HAZARD_KEYWORDS = {
    "hydrogen": ("hydrogen", "flammable"),
    "oxygen_organic_solvent": ("oxygen", "flammab", "organic solvent"),
    "pressurized_gas_liquid": ("pressure", "bpr"),
    "carbon_monoxide": ("carbon monoxide", "co detector", "toxic gas"),
    "chlorine": ("chlorine", "toxic gas"),
    "ozone": ("ozone",),
    "ozonide": ("ozonide", "peroxide"),
    "organic_peroxide": ("peroxide", "runaway"),
    "rapid_exotherm": ("exotherm", "heat removal", "cool"),
    "strong_exotherm": ("exotherm", "heat removal", "cool"),
    "exotherm": ("exotherm", "heat removal", "cool"),
    "clogging": ("clog", "pressure"),
    "overpressure": ("overpressure", "pressure relief", "bpr"),
    "solids_management": ("solid", "filter", "packed bed", "slurry"),
    "incompatible_feeds": ("incompatible", "separate", "delayed"),
    "high_pressure": ("high pressure", "bpr", "pressure"),
    "pyrophoric_catalyst": ("pyrophoric", "wet catalyst", "inert"),
    "nitric_acid": ("nitric acid", "corros"),
    "energetic_product": ("energetic", "explos", "decomposition"),
}


def _number(value: Any) -> float | None:
    try:
        number = float(value)
    except (TypeError, ValueError):
        return None
    return number if math.isfinite(number) else None


def _proposal(result: dict[str, Any]) -> dict[str, Any]:
    proposal = result.get("proposal")
    if isinstance(proposal, dict):
        return proposal
    candidate = result.get("final_design_candidate", {})
    if isinstance(candidate, dict) and isinstance(candidate.get("proposal"), dict):
        return candidate["proposal"]
    return {}


def _coverage(expected: list[str], text: str, vocabulary: dict[str, tuple[str, ...]]) -> tuple[float, dict[str, bool]]:
    checks: dict[str, bool] = {}
    for item in expected:
        terms = vocabulary.get(item, tuple(item.replace("_", " ").split()))
        checks[item] = any(term.lower() in text for term in terms)
    score = sum(checks.values()) / len(checks) if checks else 1.0
    return round(score, 4), checks


def _geometry_metrics(proposal: dict[str, Any]) -> dict[str, Any]:
    volume = _number(proposal.get("reactor_volume_mL"))
    liquid_flow = _number(proposal.get("flow_rate_mL_min"))
    tau = _number(proposal.get("residence_time_min"))
    if not volume or not liquid_flow or not tau:
        return {
            "geometry_checkable": False,
            "geometry_relative_error": None,
            "geometry_consistent_10pct": False,
        }

    gas_stp = 0.0
    gas_actual = 0.0
    gas_streams = 0
    equivalent_present = False
    streams = proposal.get("streams") or []
    if isinstance(streams, dict):
        streams = list(streams.values())
    for stream in streams:
        if not isinstance(stream, dict):
            continue
        stream_phase = str(stream.get("phase", "")).lower()
        stream_role = str(stream.get("pump_role", "")).lower()
        stream_contents = " ".join(map(str, stream.get("contents") or [])).lower()
        stream_stp = _number(stream.get("gas_flow_sccm")) or 0.0
        stream_actual = _number(stream.get("gas_flow_actual_mL_min")) or 0.0
        is_gas = (
            stream_phase == "gas"
            or stream_stp > 0
            or stream_actual > 0
            or "mass flow" in stream_role
            or "mfc" in stream_role
            or any(name in stream_contents for name in ("oxygen", "hydrogen", "chlorine", "ozone", "carbon monoxide"))
        )
        if is_gas:
            gas_streams += 1
            gas_stp += stream_stp
            gas_actual += stream_actual
            stream_equiv = (
                _number(stream.get("molar_equiv"))
                if stream.get("molar_equiv") is not None
                else _number(stream.get("equivalents"))
            )
            equivalent_present = (
                equivalent_present
                or (stream_equiv is not None and stream_equiv > 0)
            )

    basis = str(proposal.get("residence_time_basis", "")).lower()
    if "inlet" in basis or "stp" in basis:
        expected_volume = (liquid_flow + gas_stp) * tau
    elif "channel" in basis and gas_actual > 0:
        expected_volume = (liquid_flow + gas_actual) * tau
    else:
        expected_volume = liquid_flow * tau
    error = abs(volume - expected_volume) / max(volume, 1e-9)
    return {
        "geometry_checkable": True,
        "geometry_expected_volume_mL": round(expected_volume, 6),
        "geometry_relative_error": round(error, 6),
        "geometry_consistent_10pct": error <= 0.10,
        "gas_stream_count": gas_streams,
        "gas_has_stp_flow": gas_streams == 0 or gas_stp > 0,
        "gas_has_in_channel_flow": gas_streams == 0 or gas_actual > 0,
        "gas_has_equivalents": gas_streams == 0 or equivalent_present,
    }


def _inventory_metrics(proposal: dict[str, Any]) -> dict[str, Any]:
    inventory = json.loads(
        (ROOT.parents[0] / "flora_translate" / "data" / "lab_inventory.json").read_text(
            encoding="utf-8"
        )
    )
    flow = _number(proposal.get("flow_rate_mL_min"))
    volume = _number(proposal.get("reactor_volume_mL"))
    tubing_id = _number(proposal.get("tubing_ID_mm"))
    temperature = _number(proposal.get("temperature_C"))
    pressure = _number(proposal.get("BPR_bar")) or 0.0

    pump_feasible = bool(
        flow is not None
        and any(
            pump["min_flow_rate_mL_min"] <= flow <= pump["max_flow_rate_mL_min"]
            and pressure <= pump["max_pressure_bar"]
            for pump in inventory["pumps"]
        )
    )
    tubing_feasible = bool(
        tubing_id is not None
        and any(
            abs(tube["ID_mm"] - tubing_id) <= 1e-6
            and (temperature is None or temperature <= tube["max_temperature_C"])
            and pressure <= tube["max_pressure_bar"]
            for tube in inventory["tubing"]
        )
    )
    reactor_match = bool(
        volume is not None
        and tubing_id is not None
        and any(
            abs(reactor["volume_mL"] - volume) <= 1e-3
            and abs(reactor["ID_mm"] - tubing_id) <= 1e-6
            for reactor in inventory["reactors"]
        )
    )
    return {
        "inventory_pump_feasible": pump_feasible,
        "inventory_tubing_feasible": tubing_feasible,
        "inventory_exact_reactor_match": reactor_match,
    }


def _reference_metrics(case: AblationCase, proposal: dict[str, Any]) -> dict[str, Any]:
    if not case.reference_flow:
        return {
            "reference_available": False,
            "reference_accuracy_score": None,
        }
    comparisons: dict[str, Any] = {}
    normalized_errors: list[float] = []
    for field in ("residence_time_min", "flow_rate_mL_min", "reactor_volume_mL", "BPR_bar"):
        observed = _number(proposal.get(field))
        reference = _number(case.reference_flow.get(field))
        if observed is None or reference is None:
            comparisons[field] = None
            continue
        if field == "BPR_bar" and reference == 0:
            error = abs(observed - reference) / 5.0
        elif reference == 0:
            error = abs(observed - reference)
        else:
            error = abs(math.log10(max(observed, 1e-9) / reference))
        comparisons[field] = round(error, 6)
        normalized_errors.append(min(error, 2.0))

    observed_t = _number(proposal.get("temperature_C"))
    reference_t = _number(case.reference_flow.get("temperature_C"))
    if observed_t is not None and reference_t is not None:
        temp_error = abs(observed_t - reference_t)
        comparisons["temperature_C"] = round(temp_error, 6)
        normalized_errors.append(min(temp_error / 50.0, 2.0))
    else:
        comparisons["temperature_C"] = None

    score = math.exp(-sum(normalized_errors) / len(normalized_errors)) if normalized_errors else None
    return {
        "reference_available": True,
        "reference_quality": case.reference_quality,
        "reference_field_errors": comparisons,
        "reference_accuracy_score": round(score, 4) if score is not None else None,
        "reference_accuracy_primary": case.reference_quality == "machine_extracted",
    }


def _prompt_contamination(case: AblationCase, run_dir: Path) -> dict[str, Any]:
    text_parts: list[str] = []
    prompt_path = run_dir / "prompt.json"
    if prompt_path.exists():
        text_parts.append(prompt_path.read_text(encoding="utf-8").lower())
    llm_path = run_dir / "llm_events.jsonl"
    if llm_path.exists():
        for line in llm_path.read_text(encoding="utf-8").splitlines():
            try:
                event = json.loads(line)
            except json.JSONDecodeError:
                continue
            text_parts.append(str(event.get("system_prompt", "")).lower())
            text_parts.append(str(event.get("user_prompt", "")).lower())
    prompt_text = "\n".join(text_parts)
    leaked_ids = [
        record_id
        for record_id in case.excluded_record_ids
        if record_id.lower() in prompt_text
    ]

    retrieved_ids: list[str] = []
    analogy_path = run_dir / "snapshots" / "analogies.json"
    if analogy_path.exists():
        analogies = json.loads(analogy_path.read_text(encoding="utf-8"))
        for analogy in analogies:
            record_id = str(
                analogy.get("record_id")
                or analogy.get("source_pdf")
                or analogy.get("metadata", {}).get("source_pdf")
                or ""
            )
            if record_id:
                retrieved_ids.append(record_id)
    excluded_lower = {value.lower() for value in case.excluded_record_ids}
    retrieved_leaks = [value for value in retrieved_ids if value.lower() in excluded_lower]
    return {
        "prompt_source_id_leaks": leaked_ids,
        "retrieval_source_leaks": retrieved_leaks,
        "leave_one_source_out_pass": not leaked_ids and not retrieved_leaks,
    }


def _find_calculated_gas_equiv(result: dict[str, Any]) -> float | None:
    calculations = (
        result.get("frozen_context", {}).get("calculations")
        if isinstance(result.get("frozen_context"), dict)
        else None
    )
    if not isinstance(calculations, dict):
        return None
    values: list[float] = []
    for step in calculations.get("steps") or []:
        step_values = step.get("values") if isinstance(step, dict) else None
        if not isinstance(step_values, dict):
            continue
        for key in (
            "target_gas_equiv_inlet",
            "explicit_gas_equiv_inlet",
            "o2_equiv_supplied",
        ):
            number = _number(step_values.get(key))
            if number is not None:
                values.append(number)
    return max(values) if values else None


def score_run(
    case: AblationCase,
    result: dict[str, Any],
    run_dir: Path,
) -> dict[str, Any]:
    proposal = _proposal(result)
    present = {
        field: _number(proposal.get(field)) is not None
        for field in NUMERIC_FIELDS
    }
    numeric_completeness = sum(present.values()) / len(present)
    output_text = json.dumps(proposal, ensure_ascii=False).lower()
    expected = case.expected_features
    topology_score, topology_checks = _coverage(
        expected.get("topology", []),
        output_text,
        FEATURE_KEYWORDS,
    )
    safety_score, safety_checks = _coverage(
        expected.get("hazards", []),
        output_text,
        HAZARD_KEYWORDS,
    )
    geometry = _geometry_metrics(proposal)
    inventory = _inventory_metrics(proposal)
    reference = _reference_metrics(case, proposal)
    contamination = _prompt_contamination(case, run_dir)

    requires_gas = "gas" in str(expected.get("phase_regime", "")).lower()
    calculated_gas_equiv = _find_calculated_gas_equiv(result)
    gas_fields_ok = all(
        geometry.get(field, True)
        for field in (
            "gas_has_stp_flow",
            "gas_has_in_channel_flow",
            "gas_has_equivalents",
        )
    )
    if requires_gas:
        gas_fields_ok = gas_fields_ok and geometry.get("gas_stream_count", 0) > 0
        if calculated_gas_equiv is not None:
            gas_fields_ok = gas_fields_ok and calculated_gas_equiv > 0
    unexpected_gas_stream = (
        not requires_gas and geometry.get("gas_stream_count", 0) > 0
    )
    gas_fields_ok = gas_fields_ok and not unexpected_gas_stream
    deterministic_score = sum(
        (
            numeric_completeness,
            float(geometry.get("geometry_consistent_10pct", False)),
            float(inventory["inventory_pump_feasible"]),
            float(inventory["inventory_tubing_feasible"]),
            topology_score,
            safety_score,
            float(gas_fields_ok),
        )
    ) / 7.0

    return {
        "case_id": case.case_id,
        "suite_id": case.suite_id,
        "category": case.category,
        "schema_valid": bool(result.get("schema_valid", bool(proposal))),
        "numeric_field_presence": present,
        "numeric_completeness": round(numeric_completeness, 4),
        **geometry,
        **inventory,
        "topology_coverage": topology_score,
        "topology_checks": topology_checks,
        "safety_coverage": safety_score,
        "safety_checks": safety_checks,
        "gas_bookkeeping_complete": gas_fields_ok,
        "gas_required_by_case": requires_gas,
        "unexpected_gas_stream": unexpected_gas_stream,
        "calculated_gas_equiv_inlet": calculated_gas_equiv,
        **reference,
        **contamination,
        "deterministic_composite_score": round(deterministic_score, 4),
        "proposal_summary": {
            field: proposal.get(field)
            for field in NUMERIC_FIELDS
        },
    }
