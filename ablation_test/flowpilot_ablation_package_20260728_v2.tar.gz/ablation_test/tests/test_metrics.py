from pathlib import Path

from ablation_test.src.cases import load_cases
from ablation_test.src.metrics import score_run


def test_consistent_liquid_geometry_passes(tmp_path: Path):
    case = load_cases()[0]
    result = {
        "schema_valid": True,
        "proposal": {
            "residence_time_min": 10,
            "flow_rate_mL_min": 0.5,
            "reactor_volume_mL": 5,
            "temperature_C": 80,
            "concentration_M": 0.2,
            "BPR_bar": 5,
            "tubing_ID_mm": 1.0,
            "streams": [],
            "safety_flags": ["Use a back pressure regulator for hot pressurized solvent."],
        },
    }
    metrics = score_run(case, result, tmp_path)
    assert metrics["geometry_consistent_10pct"] is True
    assert metrics["numeric_completeness"] == 1.0


def test_gas_design_requires_both_flow_bases(tmp_path: Path):
    case = next(
        case
        for case in load_cases()
        if case.case_id == "aerobic_oxidation_fmoc_methionine"
    )
    result = {
        "schema_valid": True,
        "proposal": {
            "residence_time_min": 5,
            "flow_rate_mL_min": 0.1,
            "reactor_volume_mL": 1,
            "temperature_C": 25,
            "concentration_M": 0.1,
            "BPR_bar": 5,
            "tubing_ID_mm": 1.0,
            "residence_time_basis": "inlet/STP",
            "streams": [
                {
                    "phase": "gas",
                    "gas_flow_sccm": 0.1,
                    "molar_equiv": 2,
                }
            ],
        },
    }
    metrics = score_run(case, result, tmp_path)
    assert metrics["gas_has_stp_flow"] is True
    assert metrics["gas_has_in_channel_flow"] is False
    assert metrics["gas_bookkeeping_complete"] is False

